import React, { Component } from "react";

class Messages extends Component {
  renderMessage(message, index) {
    const { member, text, id } = message;
    const { currentMember, messages } = this.props;
    const messageFromMe = member.id === currentMember.id;
    let className = messageFromMe ? "Messages-message currentMember" : "Messages-message";
    const backgroundColor = member && member.clientData ? member.clientData.color : "";
  
    // Check if the current message is the latest message
    const latestMessage = messages.length - 1 === index;
    if (latestMessage) {
      className += " latest";
    }
  
    // Add animation to change background color for 1 second
    const messageStyle = {
      backgroundColor: "#b3c2ce",
      animation: latestMessage ? "changeColor 1s ease-in-out forwards" : "",
    };
  
    return (
      <li key={id ?? Math.random()} className={className} style={messageStyle}>
        <span className="avatar" style={{ backgroundColor: backgroundColor }} />
        <div className="Message-content">
          <div className="names">{member && member.clientData ? member.clientData.username : currentMember.username}</div>
          <div className="text">{text}</div>
        </div>
      </li>
    );
  }
  
  

  render() {
    const { messages } = this.props;
    return (
      <ul className="Messages-list">
        {messages.map((m, i) => this.renderMessage(m, i))}
      </ul>
    );
  }
}

export default Messages;
